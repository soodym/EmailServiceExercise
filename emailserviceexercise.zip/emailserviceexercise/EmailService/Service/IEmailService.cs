﻿using EmailService.Contracts;
using System.Threading.Tasks;

namespace EmailService.Service
{
    public interface IEmailService
    {
        Task<string> SendEmail(Email email);
    }
}
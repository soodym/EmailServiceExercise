using System;
using System.Threading.Tasks;
using EmailService.Contracts;
using EmailService.Service;
using Microsoft.Extensions.Logging;
using MockEmailClient;
using Moq;
using Xunit;

namespace EmailServiceTests
{
    public class EmailingServiceIntegrationTests
    {
        private readonly EmailingService _sut;
        private readonly Mock<ILogger<EmailingService>> _mockLogger;

        public EmailingServiceIntegrationTests()
        {
            _mockLogger = new Mock<ILogger<EmailingService>>();
            _sut = new EmailingService(new EmailClient(2), _mockLogger.Object);

        }

        //TODO: More tests!

        [Fact]
        public async void Should_Handle_SendEmail_ConnectionFailed()
        {
            var email = new Email { To = "George", Body = "Very Important!" };
            Task.Factory.StartNew(() => { _sut.SendEmail(email); });
            Task.Factory.StartNew(() => { _sut.SendEmail(email); });
            var tasks = new[] { _sut.SendEmail(email), _sut.SendEmail(email), _sut.SendEmail(email) };
            var results = await Task.WhenAll(tasks);
            Assert.Contains("Failure.", results[0].ToString());
        }

    }
}

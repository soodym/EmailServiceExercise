﻿namespace EmailService.Contracts
{
    public class Email
    {
        public string To { get; set; }
        public string Body { get; set; }
    }
}
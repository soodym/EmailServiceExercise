using System;
using System.Threading.Tasks;
using EmailService.Contracts;
using EmailService.Service;
using Microsoft.Extensions.Logging;
using MockEmailClient;
using Moq;
using Xunit;

namespace EmailServiceTests
{
    public class EmailingServiceTests
    {
        private readonly EmailingService _sut;
        private readonly Mock<IEmailClient> _mockClient;
        private readonly Mock<ILogger<EmailingService>> _mockLogger;

        public EmailingServiceTests()
        {
            _mockClient = new Mock<IEmailClient>();
            _mockLogger = new Mock<ILogger<EmailingService>>();
            _sut = new EmailingService(_mockClient.Object, _mockLogger.Object);
        }


        [Fact]
        public void Should_Send_Emails_to_Email_Client()
        {
            var email = new Email { To = "George", Body = "Very Important!" };

            _sut.SendEmail(email);
            _sut.SendEmail(email);
            _sut.SendEmail(email);
            _sut.SendEmail(email);

            _mockClient.Verify(call => call.SendEmail(email.To, email.Body), Times.Exactly(4));
        }

        [Fact]
        public async void Should_Handle_SendEmail_Failure()
        {
            var email = new Email { To = "George", Body = "Very Important!" };
            _mockClient.Setup(call => call.SendEmail(It.IsAny<string>(), It.IsAny<string>())).Throws(new Exception("Sending error"));

            var Tasks = new[] { _sut.SendEmail(email) };
            var result = await Task.WhenAll(Tasks);

            Assert.Contains("Failure.", result[0].ToString());
        }

        //TODO: More tests!
       
        [Fact]
        public async Task Should_Handle_Close_UnexpectedError()
        {
            var email = new Email { To = "George", Body = "Very Important!" };
            _mockClient.Setup(call => call.Close()).Throws(new Exception("Unexpected Error"));

            var ex = await Assert.ThrowsAsync<Exception>(() => _sut.SendEmail(email));

            Assert.Equal("Unexpected Error", ex.Message);
        }

    }
}
